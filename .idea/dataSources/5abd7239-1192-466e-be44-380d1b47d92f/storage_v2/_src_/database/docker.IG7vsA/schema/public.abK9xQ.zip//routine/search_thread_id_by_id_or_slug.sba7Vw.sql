create function search_thread_id_by_id_or_slug(slugorid character varying)
  returns integer
language plpgsql
as $$
BEGIN
  return (SELECT id from THREADS WHERE slug_lower = slugOrId);
END;
$$;

alter function search_thread_id_by_id_or_slug(varchar)
  owner to docker;

