create function update_users_of_forum(author_id numeric, forum_id numeric)
  returns void
language plpgsql
as $$
DECLARE author_data USERS;
BEGIN
  SELECT * FROM USERS WHERE id = author_id INTO author_data;
  INSERT INTO USERS_IN_FORUMS (forum_id, user_id, about, email, fullname, nickname, nickname_lower_bytea)
  VALUES (forum_id, author_id, author_data.about, author_data.email, author_data.fullname, author_data.nickname,
        (lower(author_data.nickname))::bytea)
  ON CONFLICT (forum_id, user_id) DO NOTHING;
END;
$$;

alter function update_users_of_forum(numeric, numeric)
  owner to docker;

