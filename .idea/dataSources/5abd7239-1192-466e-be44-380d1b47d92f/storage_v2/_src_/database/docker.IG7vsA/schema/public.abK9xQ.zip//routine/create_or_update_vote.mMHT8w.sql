create function create_or_update_vote(u_id integer, t_id integer, v integer)
  returns void
language plpgsql
as $$
BEGIN
  INSERT INTO votes (vote_maker, thread, voice) VALUES (u_id, t_id, v)
  ON CONFLICT (vote_maker, thread)
    DO UPDATE SET voice = v;
  UPDATE threads
  SET votes = (SELECT SUM(voice)
               FROM votes
               WHERE thread = t_id)
  WHERE id = t_id;
END;
$$;

alter function create_or_update_vote(integer, integer, integer)
  owner to docker;

