create function deleteall()
  returns void
language plpgsql
as $$
begin
  delete from votes; delete from posts; delete from threads; delete from forums; delete from users;
end;
$$;

alter function deleteall()
  owner to docker;

