create function new_thread_update_trigger()
  returns trigger
language plpgsql
as $$
BEGIN
  UPDATE THREADS_IN_FORUMS SET votes = NEW.votes where thread_id = NEW.id;
  RETURN NEW;
END;
$$;

alter function new_thread_update_trigger()
  owner to docker;

