create function search_forum_id_by_id_or_slug(slugorid integer)
  returns integer
language plpgsql
as $$
BEGIN
    return slugOrId;
  END;
$$;

alter function search_forum_id_by_id_or_slug(integer)
  owner to docker;

