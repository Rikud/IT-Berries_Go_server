create function new_post_trigger()
  returns trigger
language plpgsql
as $$
DECLARE path_array INTEGER[];
BEGIN
  IF NEW.parent = 0 THEN
    NEW.path_to_root := ARRAY[NEW.id];
  ELSE
    NEW.path_to_root := array_append((SELECT path_to_root FROM POSTS WHERE id = NEW.parent), NEW.id);
--     INSERT INTO BRANCHES(branch_id, post_id,  path_to_root) values(path_array[1], NEW.id, array_append(path_array, NEW.id));
--     UPDATE POSTS SET branch_id = (SELECT branch_id FROM POSTS WHERE id = NEW.parent) WHERE id = NEW.id;
--     NEW.branch_id = (SELECT branch_id FROM POSTS WHERE id = NEW.parent);
  END IF;
  NEW.branch_id := NEW.path_to_root[1];
  Return NEW;
END;
$$;

alter function new_post_trigger()
  owner to docker;

