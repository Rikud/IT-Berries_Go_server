create function create_post(parent_id numeric, user_nickname character varying, thread_id numeric, forum_id numeric, message_text text, created_time timestamp with time zone)
  returns numeric
language plpgsql
as $$
DECLARE author_id INTEGER;
  postId NUMERIC;
BEGIN
  SELECT search_user_id_by_nickname(user_nickname) INTO author_id;
  IF author_id ISNULL THEN
    RETURN -1;
  END IF;
  INSERT INTO POSTS (parent, author, thread, forum, message, created)
  VALUES (parent_id, author_id, thread_id, forum_id, '', created_time) RETURNING id INTO postId;
  RETURN postId;
END;
$$;

alter function create_post(numeric, varchar, numeric, numeric, text, timestamp with time zone)
  owner to docker;

