create function new_thread_trigger()
  returns trigger
language plpgsql
as $$
DECLARE author_data USERS;
BEGIN
  SELECT * FROM USERS WHERE id = NEW.author INTO author_data;
  INSERT INTO USERS_IN_FORUMS (forum_id, user_id, about, email, fullname, nickname, nickname_lower_bytea)
  VALUES (NEW.forum, NEW.author, author_data.about, author_data.email, author_data.fullname, author_data.nickname, (lower(author_data.nickname))::bytea) ON CONFLICT DO NOTHING;
  Return NEW;
END;
$$;

alter function new_thread_trigger()
  owner to docker;

