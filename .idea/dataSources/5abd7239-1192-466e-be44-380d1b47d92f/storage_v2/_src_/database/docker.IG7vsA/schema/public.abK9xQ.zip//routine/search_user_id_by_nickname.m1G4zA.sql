create function search_user_id_by_nickname(nickname_for_search character varying)
  returns integer
language plpgsql
as $$
BEGIN
  return (SELECT id from USERS WHERE nickname_lower = nickname_for_search);
END;
$$;

alter function search_user_id_by_nickname(varchar)
  owner to docker;

